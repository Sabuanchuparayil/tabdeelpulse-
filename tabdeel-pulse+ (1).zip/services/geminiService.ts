import { GoogleGenAI } from "@google/genai";
import { Message, User } from '../types';

export const summarizeConversation = async (messages: Message[], users: User[]): Promise<string> => {
    // ===================================================================================
    // CRITICAL SECURITY WARNING
    // ===================================================================================
    // This function is running on the client-side (in the user's browser).
    // Exposing `process.env.API_KEY` here is a SEVERE security vulnerability.
    // Anyone could view the source code of this web app and steal your API key.
    //
    // In a production application, you MUST move this logic to a secure backend server.
    // The flow should be:
    // 1. Client-side sends the conversation data to your backend API endpoint.
    // 2. Your backend server securely calls the Gemini API with your key.
    // 3. Your backend server sends the summary result back to the client.
    //
    // DO NOT DEPLOY THIS CODE TO PRODUCTION AS-IS.
    // ===================================================================================

    if (!process.env.API_KEY) {
        console.warn("API_KEY environment variable not set. Using mock summary.");
        return new Promise(resolve => setTimeout(() => resolve(
            "This is a mock summary.\n\nKey Points:\n- A user reported an issue.\n- A technician is investigating.\n\nAction Items:\n- Technician to provide an update within the hour."
        ), 1000));
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const userMap = new Map(users.map(u => [u.id, u.name]));

    const formattedConversation = messages.map(msg => {
        const senderName = userMap.get(msg.senderId) || 'Unknown User';
        return `${senderName}: ${msg.content}`;
    }).join('\n');

    const prompt = `Summarize the following conversation from an internal business chat application. Highlight key points and any action items. Be concise and professional.

Conversation:
---
${formattedConversation}
---
Summary:`;

    try {
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error summarizing conversation:", error);
        return "Error: Could not generate a summary.";
    }
};