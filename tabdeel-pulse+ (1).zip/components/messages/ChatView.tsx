import React, { useState, useContext, useRef, useEffect } from 'react';
import { ChatThread, User } from '../../types';
import { AuthContext } from '../../contexts/AuthContext';
import { useApi } from '../../hooks/useApi';
import { summarizeConversation } from '../../services/geminiService';
import Modal from '../common/Modal';
import Icon from '../common/Icon';
import Avatar from '../common/Avatar';

interface ChatViewProps {
    thread: ChatThread;
    users: User[];
    onMessageSent: (updatedThread: ChatThread) => void;
    onBack: () => void;
}

const ChatView: React.FC<ChatViewProps> = ({ thread, users, onMessageSent, onBack }) => {
    const [newMessage, setNewMessage] = useState('');
    const [isSummarizing, setIsSummarizing] = useState(false);
    const [summary, setSummary] = useState('');
    const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);
    const { user } = useContext(AuthContext)!;
    const api = useApi();
    const userMap = new Map(users.map(u => [u.id, u]));
    const messagesEndRef = useRef<HTMLDivElement>(null);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [thread.messages]);

    const handleSendMessage = async () => {
        if (!newMessage.trim() || !user) return;
        const updatedThread = await api.addMessage(thread.id, { senderId: user.id, content: newMessage });
        if (updatedThread) {
            onMessageSent(updatedThread);
            setNewMessage('');
        }
    };

    const handleSummarize = async () => {
        setIsSummarizing(true);
        const summaryText = await summarizeConversation(thread.messages, users);
        setSummary(summaryText);
        setIsSummarizing(false);
        setIsSummaryModalOpen(true);
    };

    return (
        <>
            <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                <div className="flex items-center">
                    <button onClick={onBack} className="mr-2 md:hidden p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
                        <Icon name="arrow-left" className="w-6 h-6" />
                    </button>
                    <div>
                        <h3 className="text-lg font-bold">{thread.title}</h3>
                        <p className="text-sm text-gray-500">
                            {thread.participants.map(pId => userMap.get(pId)?.name.split(' ')[0]).join(', ')}
                        </p>
                    </div>
                </div>
                <button
                    onClick={handleSummarize}
                    disabled={isSummarizing}
                    className="px-3 py-1.5 text-sm rounded-lg bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300 hover:bg-indigo-200 disabled:opacity-50"
                >
                    {isSummarizing ? 'Summarizing...' : 'AI Summary'}
                </button>
            </div>
            
            <div className="flex-1 p-4 overflow-y-auto bg-gray-50 dark:bg-gray-900/20">
                <div className="space-y-4">
                    {thread.messages.map(message => {
                        const sender = userMap.get(message.senderId);
                        const isCurrentUser = sender?.id === user?.id;
                        return (
                             <div key={message.id} className={`flex items-end gap-2 ${isCurrentUser ? 'justify-end' : 'justify-start'}`}>
                                {!isCurrentUser && sender && <Avatar name={sender.name} size="sm" />}
                                <div className={`max-w-md p-3 rounded-xl ${isCurrentUser ? 'bg-primary-light text-white rounded-br-none' : 'bg-white dark:bg-dark-bg-card rounded-bl-none'}`}>
                                    <p className="text-sm">{message.content}</p>
                                    <p className={`text-xs mt-1 opacity-70 ${isCurrentUser ? 'text-right' : 'text-left'}`}>{new Date(message.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                                </div>
                                 {isCurrentUser && sender && <Avatar name={sender.name} size="sm" />}
                            </div>
                        )
                    })}
                </div>
                <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t dark:border-gray-700">
                <div className="flex space-x-2">
                    <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        placeholder="Type a message..."
                        className="flex-grow p-2 border rounded-lg bg-transparent dark:border-gray-600 focus:outline-none focus:ring-1 focus:ring-primary-light"
                    />
                    <button onClick={handleSendMessage} className="px-4 py-2 rounded-lg bg-primary-light text-white">Send</button>
                </div>
            </div>
            
            <Modal isOpen={isSummaryModalOpen} onClose={() => setIsSummaryModalOpen(false)} title="Conversation Summary">
                <div className="whitespace-pre-wrap text-sm">{summary}</div>
            </Modal>
        </>
    );
};

export default ChatView;
